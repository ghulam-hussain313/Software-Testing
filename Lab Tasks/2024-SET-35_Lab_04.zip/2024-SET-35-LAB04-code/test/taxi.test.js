import { describe, test } from 'node:test';
import assert from 'node:assert/strict';
import {
  fareForRide,
  totalFare,
  applyPeakSurcharge,
  waitingCharge,
  rideSummary,
  totalDistance,
} from '../src/taxi.js';

describe('fareForRide (R1)', () => {
  test('multiplies distance by rate for a whole-number fare', () => {
    // Arrange
    const distanceKm = 10;
    const ratePerKm = 25;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert: 10 x 25 = 250
    assert.strictEqual(result, 250);
  });

  test('rounds a half-rupee fare up to the nearest rupee', () => {
    // Arrange
    const distanceKm = 3.5;
    const ratePerKm = 33;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert: 3.5 x 33 = 115.5 -> 116
    assert.strictEqual(result, 116);
  });

  test('rounds a fare below half a rupee down to the nearest rupee', () => {
    // Arrange
    const distanceKm = 3.2;
    const ratePerKm = 7;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert: 3.2 x 7 = 22.4 -> 22
    assert.strictEqual(result, 22);
  });
});

describe('totalFare (R2)', () => {
  test('adds the fares of several rides', () => {
    // Arrange
    const rides = [
      { distanceKm: 10, ratePerKm: 25 },
      { distanceKm: 5, ratePerKm: 30 },
      { distanceKm: 2, ratePerKm: 40 },
    ];
    // Act
    const result = totalFare(rides);
    // Assert: 250 + 150 + 80 = 480
    assert.strictEqual(result, 480);
  });

  test('returns 0 for an empty list of rides', () => {
    // Arrange
    const rides = [];
    // Act
    const result = totalFare(rides);
    // Assert: no rides -> 0
    assert.strictEqual(result, 0);
  });

  test('rounds each ride fare (R1) before adding them', () => {
    // Arrange
    const rides = [
      { distanceKm: 3.5, ratePerKm: 33 },
      { distanceKm: 3.5, ratePerKm: 33 },
    ];
    // Act
    const result = totalFare(rides);
    // Assert: 116 + 116 = 232 (not 231, which would come from adding the unrounded 115.5 + 115.5)
    assert.strictEqual(result, 232);
  });
});

describe('applyPeakSurcharge (R3)', () => {
  test('adds a 20 percent surcharge to a round amount', () => {
    // Arrange
    const amount = 1000;
    const percent = 20;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert: 1000 + 200 = 1200
    assert.strictEqual(result, 1200);
  });

  test('adds a 10 percent surcharge to 250', () => {
    // Arrange
    const amount = 250;
    const percent = 10;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert: 250 + 25 = 275
    assert.strictEqual(result, 275);
  });

  test('rounds a fractional surcharged amount to the nearest rupee', () => {
    // Arrange
    const amount = 333;
    const percent = 15;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert: 333 + 49.95 = 382.95 -> 383
    assert.strictEqual(result, 383);
  });

  test('leaves the amount unchanged when the surcharge is 0 percent', () => {
    // Arrange
    const amount = 500;
    const percent = 0;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert: 500 + 0 = 500
    assert.strictEqual(result, 500);
  });
});

describe('waitingCharge (R4)', () => {
  test('charges nothing at 4 minutes (below the free limit)', () => {
    // Arrange
    const minutes = 4;
    // Act
    const result = waitingCharge(minutes);
    // Assert: within the first 5 free minutes -> 0
    assert.strictEqual(result, 0);
  });

  test('charges nothing at exactly 5 minutes (boundary of the free limit)', () => {
    // Arrange
    const minutes = 5;
    // Act
    const result = waitingCharge(minutes);
    // Assert: first 5 minutes are free -> 0
    assert.strictEqual(result, 0);
  });

  test('charges Rs 10 at 6 minutes (one minute beyond the free limit)', () => {
    // Arrange
    const minutes = 6;
    // Act
    const result = waitingCharge(minutes);
    // Assert: (6 - 5) x 10 = 10
    assert.strictEqual(result, 10);
  });

  test('charges Rs 10 per minute for every minute beyond 5', () => {
    // Arrange
    const minutes = 15;
    // Act
    const result = waitingCharge(minutes);
    // Assert: (15 - 5) x 10 = 100
    assert.strictEqual(result, 100);
  });
});

describe('rideSummary (R5)', () => {
  test('returns fare, surcharge, waiting charge and total for a typical trip', () => {
    // Arrange
    const rides = [
      { distanceKm: 10, ratePerKm: 25 },
      { distanceKm: 5, ratePerKm: 30 },
    ];
    // Act
    const result = rideSummary(rides, 25, 8);
    // Assert: fare 250+150=400; surcharge 500-400=100; waiting (8-5)x10=30; total 530
    assert.deepStrictEqual(result, {
      fare: 400,
      surcharge: 100,
      waitingCharge: 30,
      total: 530,
    });
  });

  test('returns all zeros for no rides, no surcharge and no waiting', () => {
    // Arrange
    const rides = [];
    // Act
    const result = rideSummary(rides, 0, 0);
    // Assert: every component is 0
    assert.deepStrictEqual(result, {
      fare: 0,
      surcharge: 0,
      waitingCharge: 0,
      total: 0,
    });
  });

  test('reports the surcharge as the extra rupees added on top of the fare', () => {
    // Arrange
    const rides = [{ distanceKm: 3.5, ratePerKm: 33 }];
    // Act
    const result = rideSummary(rides, 10, 5);
    // Assert: fare 116; 116 x 1.10 = 127.6 -> 128; surcharge 12; waiting 0; total 128
    assert.deepStrictEqual(result, {
      fare: 116,
      surcharge: 12,
      waitingCharge: 0,
      total: 128,
    });
  });
});

describe('totalDistance (R6)', () => {
  test('adds the distance of every ride', () => {
    // Arrange
    const rides = [
      { distanceKm: 10, ratePerKm: 25 },
      { distanceKm: 5, ratePerKm: 30 },
      { distanceKm: 2.5, ratePerKm: 40 },
    ];
    // Act
    const result = totalDistance(rides);
    // Assert: 10 + 5 + 2.5 = 17.5
    assert.strictEqual(result, 17.5);
  });

  test('returns 0 for an empty list of rides', () => {
    // Arrange
    const rides = [];
    // Act
    const result = totalDistance(rides);
    // Assert: no rides -> 0
    assert.strictEqual(result, 0);
  });
});
