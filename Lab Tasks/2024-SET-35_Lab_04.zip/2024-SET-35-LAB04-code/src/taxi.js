// src/taxi.js

// R1: distance x rate, rounded to the nearest whole rupee
export function fareForRide(distanceKm, ratePerKm) {
  return Math.round(distanceKm * ratePerKm);
}

// R2: sum of R1 fares for all rides; empty list -> 0
export function totalFare(rides) {
  let sum = 0;
  for (const ride of rides) {
    sum += fareForRide(ride.distanceKm, ride.ratePerKm);
  }
  return sum;
}

// R3: increase amount by percent, rounded to the nearest whole rupee
export function applyPeakSurcharge(amount, percent) {
  return Math.round(amount + (amount * percent) / 100);
}

// R4: first 5 minutes free, Rs 10 for every minute beyond 5
export function waitingCharge(minutes) {
  if (minutes <= 5) {
    return 0;
  }
  return (minutes - 5) * 10;
}

// R5: summary of fare, surcharge, waiting charge and total
export function rideSummary(rides, surchargePercent, minutesWaited) {
  const fare = totalFare(rides);
  const surcharge = applyPeakSurcharge(fare, surchargePercent) - fare;
  const waiting = waitingCharge(minutesWaited);
  return {
    fare,
    surcharge,
    waitingCharge: waiting,
    total: fare + surcharge + waiting,
  };
}

// R6: sum of distanceKm across all rides; empty list -> 0
export function totalDistance(rides) {
  let sum = 0;
  for (const ride of rides) {
    sum += ride.distanceKm;
  }
  return sum;
}
